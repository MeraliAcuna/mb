export interface User{
    nombre : string
    correo : string
    telefono : string
}